# Data Science Course - Class 2
_This material is created for our [Data Science with Python Course](https://rmotr.com/data-science-python-course)_
